"""Terminology management module."""
