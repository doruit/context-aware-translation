"""Azure Translation Service with Glossary Enforcement - Preserve domain-specific terminology during translation."""
